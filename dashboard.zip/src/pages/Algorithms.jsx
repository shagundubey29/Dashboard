import React from 'react'

const Algorithms = () => {
  return (
    <div>Algorithms</div>
  )
}

export default Algorithms