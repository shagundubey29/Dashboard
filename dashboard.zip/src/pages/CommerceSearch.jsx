
const CommerceSearch = () => {
  return (
    <div>CommerceSearch</div>
  )
}

export default CommerceSearch